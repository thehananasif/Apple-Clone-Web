"use client";

import Link from "next/link";
import { ChevronDown } from "lucide-react";
import { useState } from "react";

interface FooterColumnProps {
  title: string;
  links: { label: string; href: string }[];
  isOpen?: boolean;
  toggleOpen?: () => void;
}

const FooterColumn = ({ title, links, isOpen, toggleOpen }: FooterColumnProps) => {
  return (
    <div className="border-b border-gray-700 md:border-0">
      <div
        className="flex justify-between items-center py-3 md:py-0 md:mb-2 cursor-pointer md:cursor-default"
        onClick={toggleOpen}
      >
        <h3 className="text-sm font-normal text-gray-400">{title}</h3>
        <ChevronDown
          className={`w-4 h-4 text-gray-400 md:hidden transition-transform ${isOpen ? 'rotate-180' : ''}`}
        />
      </div>
      <ul className={`space-y-2 ${isOpen ? 'block' : 'hidden'} md:block mb-4`}>
        {links.map((link, i) => (
          <li key={`${title}-${link.label}`}>
            <Link
              href={link.href}
              className="text-xs text-gray-400 hover:underline"
            >
              {link.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export function Footer() {
  const [openColumns, setOpenColumns] = useState<{ [key: string]: boolean }>({});

  const toggleColumn = (title: string) => {
    setOpenColumns(prev => ({
      ...prev,
      [title]: !prev[title]
    }));
  };

  const shopAndLearnLinks = [
    { label: "Store", href: "/store" },
    { label: "Mac", href: "/mac" },
    { label: "iPad", href: "/ipad" },
    { label: "iPhone", href: "/iphone" },
    { label: "Watch", href: "/watch" },
    { label: "Vision Pro", href: "/vision-pro" },
    { label: "AirPods", href: "/" },
    { label: "TV & Home", href: "/" },
    { label: "AirTag", href: "/" },
    { label: "Accessories", href: "/" },
    { label: "Gift Cards", href: "/" },
  ];

  const servicesLinks = [
    { label: "Apple Music", href: "/" },
    { label: "Apple TV+", href: "/" },
    { label: "Apple Fitness+", href: "/" },
    { label: "Apple News+", href: "/" },
    { label: "Apple Arcade", href: "/" },
    { label: "iCloud", href: "/" },
    { label: "Apple One", href: "/" },
    { label: "Apple Card", href: "/" },
    { label: "Apple Books", href: "/" },
    { label: "Apple Podcasts", href: "/" },
    { label: "App Store", href: "/" },
  ];

  const accountLinks = [
    { label: "Manage Your Apple ID", href: "/" },
    { label: "Apple Store Account", href: "/" },
    { label: "iCloud.com", href: "/" },
  ];

  const storeLinks = [
    { label: "Find a Store", href: "/" },
    { label: "Genius Bar", href: "/" },
    { label: "Today at Apple", href: "/" },
    { label: "Apple Camp", href: "/" },
    { label: "Apple Store App", href: "/" },
    { label: "Certified Refurbished", href: "/" },
    { label: "Apple Trade In", href: "/" },
    { label: "Financing", href: "/" },
    { label: "Carrier Deals at Apple", href: "/" },
    { label: "Order Status", href: "/" },
    { label: "Shopping Help", href: "/" },
  ];

  const businessLinks = [
    { label: "Apple and Business", href: "/" },
    { label: "Shop for Business", href: "/" },
  ];

  const educationLinks = [
    { label: "Apple and Education", href: "/" },
    { label: "Shop for K-12", href: "/" },
    { label: "Shop for College", href: "/" },
  ];

  const valuesLinks = [
    { label: "Accessibility", href: "/" },
    { label: "Education", href: "/" },
    { label: "Environment", href: "/" },
    { label: "Inclusion and Diversity", href: "/" },
    { label: "Privacy", href: "/" },
    { label: "Racial Equity and Justice", href: "/" },
    { label: "Supplier Responsibility", href: "/" },
  ];

  const aboutLinks = [
    { label: "Newsroom", href: "/" },
    { label: "Apple Leadership", href: "/" },
    { label: "Career Opportunities", href: "/" },
    { label: "Investors", href: "/" },
    { label: "Ethics & Compliance", href: "/" },
    { label: "Events", href: "/" },
    { label: "Contact Apple", href: "/" },
  ];

  const footerColumns = [
    { title: "Shop and Learn", links: shopAndLearnLinks },
    { title: "Services", links: servicesLinks },
    { title: "Account", links: accountLinks },
    { title: "Apple Store", links: storeLinks },
    { title: "For Business", links: businessLinks },
    { title: "For Education", links: educationLinks },
    { title: "Apple Values", links: valuesLinks },
    { title: "About Apple", links: aboutLinks },
  ];

  return (
    <footer className="bg-[#f5f5f7] text-gray-600 py-8 md:py-12">
      <div className="max-w-[980px] mx-auto px-4 sm:px-6">
        {/* Main footer content */}
        <div className="border-b border-gray-300 pb-8">
          <p className="text-xs mb-6">
            To access and use all the features of Apple Card, you must add Apple Card to Wallet on an iPhone or iPad with the latest version of iOS or iPadOS. Update to the latest version by going to Settings {">"} General {">"} Software Update. Tap Download and Install.
          </p>
          <p className="text-xs mb-6">
            Available for qualifying applicants in the United States.
          </p>
          <p className="text-xs mb-6">
            Apple Card is issued by Goldman Sachs Bank USA, Salt Lake City Branch.
          </p>
          <p className="text-xs">
            Learn more about how Apple Card applications are evaluated at <Link href="/" className="text-blue-500 hover:underline">support.apple.com/kb/HT209218</Link>.
          </p>
        </div>

        {/* Footer links */}
        <div className="grid md:grid-cols-5 gap-0 md:gap-6 my-8">
          <div className="md:col-span-2 grid md:grid-cols-2 gap-0 md:gap-6">
            <FooterColumn
              title={footerColumns[0].title}
              links={footerColumns[0].links}
              isOpen={openColumns[footerColumns[0].title]}
              toggleOpen={() => toggleColumn(footerColumns[0].title)}
            />
            <div>
              <FooterColumn
                title={footerColumns[1].title}
                links={footerColumns[1].links}
                isOpen={openColumns[footerColumns[1].title]}
                toggleOpen={() => toggleColumn(footerColumns[1].title)}
              />
              <FooterColumn
                title={footerColumns[2].title}
                links={footerColumns[2].links}
                isOpen={openColumns[footerColumns[2].title]}
                toggleOpen={() => toggleColumn(footerColumns[2].title)}
              />
            </div>
          </div>
          <div className="md:col-span-3 grid md:grid-cols-3 gap-0 md:gap-6">
            <FooterColumn
              title={footerColumns[3].title}
              links={footerColumns[3].links}
              isOpen={openColumns[footerColumns[3].title]}
              toggleOpen={() => toggleColumn(footerColumns[3].title)}
            />
            <div>
              <FooterColumn
                title={footerColumns[4].title}
                links={footerColumns[4].links}
                isOpen={openColumns[footerColumns[4].title]}
                toggleOpen={() => toggleColumn(footerColumns[4].title)}
              />
              <FooterColumn
                title={footerColumns[5].title}
                links={footerColumns[5].links}
                isOpen={openColumns[footerColumns[5].title]}
                toggleOpen={() => toggleColumn(footerColumns[5].title)}
              />
            </div>
            <div>
              <FooterColumn
                title={footerColumns[6].title}
                links={footerColumns[6].links}
                isOpen={openColumns[footerColumns[6].title]}
                toggleOpen={() => toggleColumn(footerColumns[6].title)}
              />
              <FooterColumn
                title={footerColumns[7].title}
                links={footerColumns[7].links}
                isOpen={openColumns[footerColumns[7].title]}
                toggleOpen={() => toggleColumn(footerColumns[7].title)}
              />
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-gray-300 pt-5 text-xs text-gray-600">
          <div className="flex flex-col md:flex-row md:justify-between">
            <div className="mb-4 md:mb-0">
              <p className="mb-2">Copyright © {new Date().getFullYear()} Apple Inc. All rights reserved.</p>
              <div className="flex flex-wrap gap-2">
                <Link href="/" className="hover:underline">Privacy Policy</Link>
                <span>|</span>
                <Link href="/" className="hover:underline">Terms of Use</Link>
                <span>|</span>
                <Link href="/" className="hover:underline">Sales and Refunds</Link>
                <span>|</span>
                <Link href="/" className="hover:underline">Legal</Link>
                <span>|</span>
                <Link href="/" className="hover:underline">Site Map</Link>
              </div>
            </div>
            <div>
              <p>United States</p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
