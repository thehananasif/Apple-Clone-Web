"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Search, ShoppingBag, X, Menu } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

const navItems = [
  { label: "Store", href: "/store" },
  { label: "Mac", href: "/mac" },
  { label: "iPad", href: "/ipad" },
  { label: "iPhone", href: "/iphone" },
  { label: "Watch", href: "/watch" },
  { label: "Vision Pro", href: "/vision-pro" },
  { label: "AirPods", href: "/" },
  { label: "TV & Home", href: "/" },
  { label: "Entertainment", href: "/" },
  { label: "Accessories", href: "/" },
  { label: "Support", href: "/" },
];

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? "bg-[rgba(22,22,23,0.8)] backdrop-blur-md"
          : "bg-[#161617]"
      }`}
    >
      <div className="max-w-[980px] mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-12">
          {/* Logo */}
          <Link href="/" className="text-white">
            <svg
              height="44"
              viewBox="0 0 14 44"
              width="14"
              xmlns="http://www.w3.org/2000/svg"
              className="w-3.5 h-11 fill-current"
            >
              <path d="m13.0729 17.6825a3.61 3.61 0 0 0 -1.7248 3.0365 3.5132 3.5132 0 0 0 2.1379 3.2223 8.394 8.394 0 0 1 -1.0948 2.2618c-.6816.9812-1.3943 1.9623-2.4787 1.9623s-1.3633-.63-2.613-.63c-1.2187 0-1.6525.6507-2.644.6507s-1.6834-.9089-2.4787-2.0243a9.7842 9.7842 0 0 1 -1.6628-5.2776c0-3.0984 2.014-4.7405 3.9969-4.7405 1.0535 0 1.9314.6919 2.5924.6919.63 0 1.6112-.7333 2.8092-.7333a3.7579 3.7579 0 0 1 3.1468 1.5802zm-3.7263-2.8918a3.5615 3.5615 0 0 0 .8469-2.22 1.5353 1.5353 0 0 0 -.031-.32 3.5686 3.5686 0 0 0 -2.3445 1.2084 3.4629 3.4629 0 0 0 -.8779 2.1585 1.419 1.419 0 0 0 .031.2892 1.19 1.19 0 0 0 .2169.0207 3.0935 3.0935 0 0 0 2.1586-1.1368z" />
            </svg>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex">
            <ul className="flex space-x-7">
              {navItems.map((item) => (
                <li key={`nav-${item.label}`}>
                  <Link
                    href={item.href}
                    className="text-[#f5f5f7] text-xs font-light opacity-80 hover:opacity-100"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          {/* Icons */}
          <div className="flex items-center space-x-4">
            <button className="text-[#f5f5f7] opacity-80 hover:opacity-100">
              <Search className="w-4 h-4" />
            </button>
            <button className="text-[#f5f5f7] opacity-80 hover:opacity-100">
              <ShoppingBag className="w-4 h-4" />
            </button>

            {/* Mobile Menu Toggle */}
            <Sheet>
              <SheetTrigger asChild className="md:hidden">
                <button className="text-[#f5f5f7] opacity-80 hover:opacity-100">
                  <Menu className="w-5 h-5" />
                </button>
              </SheetTrigger>
              <SheetContent side="top" className="pt-12 bg-[#161617]">
                <nav>
                  <ul className="space-y-4">
                    {navItems.map((item) => (
                      <li key={`mobile-${item.label}`} className="py-2 border-b border-gray-700">
                        <Link
                          href={item.href}
                          className="text-[#f5f5f7] text-lg font-light"
                        >
                          {item.label}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
