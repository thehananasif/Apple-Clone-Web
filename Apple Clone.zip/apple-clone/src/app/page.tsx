"use client";

import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";

interface ProductSectionProps {
  title: string;
  subtitle: string;
  imageSrc: string;
  imageAlt: string;
  darkMode?: boolean;
  learnMoreLink?: string;
  buyLink?: string;
  imageWidth?: number;
  imageHeight?: number;
  additionalText?: string;
}

const ProductSection = ({
  title,
  subtitle,
  imageSrc,
  imageAlt,
  darkMode = false,
  learnMoreLink = "/",
  buyLink = "/",
  imageWidth = 800,
  imageHeight = 500,
  additionalText,
}: ProductSectionProps) => {
  return (
    <section
      className={`relative px-4 ${
        darkMode ? "bg-black text-white" : "bg-[#f5f5f7] text-black"
      } py-16 sm:py-24 overflow-hidden flex flex-col items-center text-center`}
    >
      <h2 className="text-4xl sm:text-5xl font-semibold z-10">{title}</h2>
      <p className="text-xl sm:text-2xl mt-2 z-10">{subtitle}</p>

      {additionalText && (
        <p className="text-md mt-2 z-10 text-center max-w-md">{additionalText}</p>
      )}

      <div className="flex space-x-4 mt-4 z-10">
        <Link
          href={learnMoreLink}
          className="text-[#2997ff] hover:underline text-lg flex items-center"
        >
          Learn more <span className="ml-1">&gt;</span>
        </Link>
        <Link
          href={buyLink}
          className="text-[#2997ff] hover:underline text-lg flex items-center"
        >
          Buy <span className="ml-1">&gt;</span>
        </Link>
      </div>

      <div className="mt-8 relative w-full max-w-4xl mx-auto">
        <Image
          src={imageSrc}
          alt={imageAlt}
          width={imageWidth}
          height={imageHeight}
          className="w-full h-auto object-contain z-0"
          priority
        />
      </div>
    </section>
  );
};

export default function HomePage() {
  return (
    <div className="w-full">
      {/* MacBook Air Section */}
      <ProductSection
        title="MacBook Air"
        subtitle="Sky blue color. Sky high performance with M4."
        imageSrc="https://ext.same-assets.com/904505210/702855466.png"
        imageAlt="MacBook Air"
        darkMode={false}
        additionalText="Built for Apple Intelligence."
      />

      {/* MacBook Pro Section */}
      <ProductSection
        title="MacBook Pro"
        subtitle="A work of smart."
        imageSrc="https://www.apple.com/v/home/cd/images/heroes/macbook-pro/hero_macbookpro__dlsjsogoix6a_large.jpg"
        imageAlt="MacBook Pro"
        darkMode={true}
        additionalText="Built for Apple Intelligence."
      />

      {/* iPad Pro Section */}
      <ProductSection
        title="iPad Pro"
        subtitle="Unbelievably thin. Incredibly powerful."
        imageSrc="https://www.apple.com/v/home/cd/images/heroes/ipad-pro/hero_ipadpro__6dn1o5f1asye_large.jpg"
        imageAlt="iPad Pro"
        darkMode={true}
        additionalText="Built for Apple Intelligence."
      />

      {/* Two-column Grid Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 px-3 bg-[#f5f5f7]">
        {/* iPhone 16 Pro */}
        <div className="bg-black text-white px-4 py-12 flex flex-col items-center text-center rounded-2xl">
          <h2 className="text-3xl font-semibold">iPhone 16 Pro</h2>
          <p className="text-md">Built for Apple Intelligence.</p>
          <div className="flex space-x-4 mt-3">
            <Link
              href="/"
              className="text-[#2997ff] hover:underline text-md flex items-center"
            >
              Learn more <span className="ml-1">&gt;</span>
            </Link>
            <Link
              href="/"
              className="text-[#2997ff] hover:underline text-md flex items-center"
            >
              Buy <span className="ml-1">&gt;</span>
            </Link>
          </div>
          <div className="mt-4">
            <Image
              src="https://ext.same-assets.com/904505210/475379279.jpeg"
              alt="iPhone 16 Pro"
              width={400}
              height={300}
              className="w-full h-auto object-contain"
            />
          </div>
        </div>

        {/* iPhone 16 */}
        <div className="bg-[#f5f5f7] text-black px-4 py-12 flex flex-col items-center text-center rounded-2xl">
          <h2 className="text-3xl font-semibold">iPhone 16</h2>
          <p className="text-md">Built for Apple Intelligence.</p>
          <div className="flex space-x-4 mt-3">
            <Link
              href="/"
              className="text-[#2997ff] hover:underline text-md flex items-center"
            >
              Learn more <span className="ml-1">&gt;</span>
            </Link>
            <Link
              href="/"
              className="text-[#2997ff] hover:underline text-md flex items-center"
            >
              Buy <span className="ml-1">&gt;</span>
            </Link>
          </div>
          <div className="mt-4">
            <Image
              src="https://ext.same-assets.com/904505210/1225220529.jpeg"
              alt="iPhone 16"
              width={400}
              height={300}
              className="w-full h-auto object-contain"
            />
          </div>
        </div>

        {/* Apple Watch */}
        <div className="bg-[#f5f5f7] text-black px-4 py-12 flex flex-col items-center text-center rounded-2xl">
          <Image
            src="https://ext.same-assets.com/904505210/702619004.jpeg"
            alt="Apple Watch"
            width={140}
            height={50}
            className="h-12 w-auto object-contain mb-3"
          />
          <p className="text-md">Thousand classic.</p>
          <div className="flex space-x-4 mt-3">
            <Link
              href="/"
              className="text-[#2997ff] hover:underline text-md flex items-center"
            >
              Learn more <span className="ml-1">&gt;</span>
            </Link>
            <Link
              href="/"
              className="text-[#2997ff] hover:underline text-md flex items-center"
            >
              Buy <span className="ml-1">&gt;</span>
            </Link>
          </div>
          <div className="mt-4">
            <Image
              src="https://ext.same-assets.com/904505210/702619004.jpeg"
              alt="Apple Watch Series 10"
              width={400}
              height={300}
              className="w-full h-auto object-contain"
            />
          </div>
        </div>

        {/* Mac does that */}
        <div className="bg-[#f5f5f7] text-black px-4 py-12 flex flex-col items-center text-center rounded-2xl">
          <div className="flex items-center space-x-2">
            <h2 className="text-3xl font-semibold">Mac does</h2>
            <span className="text-3xl font-semibold bg-green-500 px-2 py-1 rounded">that</span>
          </div>
          <p className="text-md">See how easy it is to switch to Mac.</p>
          <div className="flex space-x-4 mt-3">
            <Link
              href="/"
              className="text-[#2997ff] hover:underline text-md flex items-center"
            >
              Learn more <span className="ml-1">&gt;</span>
            </Link>
          </div>
          <div className="mt-4">
            <Image
              src="https://ext.same-assets.com/904505210/485267094.jpeg"
              alt="Mac devices"
              width={400}
              height={300}
              className="w-full h-auto object-contain"
            />
          </div>
        </div>

        {/* Trade In */}
        <div className="bg-[#f5f5f7] text-black px-4 py-12 flex flex-col items-center text-center rounded-2xl">
          <Image
            src="https://ext.same-assets.com/904505210/485710749.png"
            alt="Trade In"
            width={140}
            height={50}
            className="h-10 w-auto object-contain mb-3"
          />
          <p className="text-md">Get $170-$650 in credit when you trade in iPhone 12 or higher.*</p>
          <div className="flex space-x-4 mt-3">
            <Link
              href="/"
              className="text-[#2997ff] hover:underline text-md flex items-center"
            >
              See what your device is worth <span className="ml-1">&gt;</span>
            </Link>
          </div>
          <div className="mt-4">
            <Image
              src="https://ext.same-assets.com/904505210/758907657.jpeg"
              alt="iPhone Trade In"
              width={400}
              height={300}
              className="w-full h-auto object-contain"
            />
          </div>
        </div>

        {/* Apple Card */}
        <div className="bg-[#f5f5f7] text-black px-4 py-12 flex flex-col items-center text-center rounded-2xl">
          <Image
            src="https://ext.same-assets.com/904505210/998056807.png"
            alt="Apple Card"
            width={140}
            height={50}
            className="h-8 w-auto object-contain mb-3"
          />
          <p className="text-md">Get up to 3% Daily Cash back with every purchase.</p>
          <div className="flex space-x-4 mt-3">
            <Link
              href="/"
              className="text-[#2997ff] hover:underline text-md flex items-center"
            >
              Learn more <span className="ml-1">&gt;</span>
            </Link>
            <Link
              href="/"
              className="text-[#2997ff] hover:underline text-md flex items-center"
            >
              Apply now <span className="ml-1">&gt;</span>
            </Link>
          </div>
          <div className="mt-4">
            <Image
              src="https://ext.same-assets.com/904505210/1923740808.jpeg"
              alt="Apple Card"
              width={400}
              height={300}
              className="w-full h-auto object-contain"
            />
          </div>
        </div>
      </div>

      {/* TV+ Section */}
      <section className="bg-black text-white px-4 py-16 flex flex-col items-center text-center">
        <h2 className="text-4xl font-semibold">
          YOUR FRIENDS & NEIGHBORS
        </h2>
        <div className="flex items-center mt-2 mb-4">
          <p className="text-md mr-2">Stream now</p>
          <span className="w-px h-4 bg-white mx-2" />
          <p className="text-md">Drama | Live your best lie.</p>
        </div>
        <div className="mt-4 max-w-4xl mx-auto">
          <Image
            src="https://ext.same-assets.com/904505210/4047110055.jpeg"
            alt="TV+ Show"
            width={800}
            height={450}
            className="w-full h-auto object-contain rounded-xl"
          />
        </div>
      </section>
    </div>
  );
}
