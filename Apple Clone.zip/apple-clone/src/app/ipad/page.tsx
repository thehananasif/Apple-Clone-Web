"use client";

import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";

export default function IPadPage() {
  return (
    <div className="w-full pt-12">
      {/* Hero Section */}
      <section className="bg-black text-white py-16 px-4 text-center">
        <h1 className="text-5xl sm:text-6xl font-bold mb-4">iPad Pro</h1>
        <p className="text-xl sm:text-2xl mb-6">Unbelievably thin. Incredibly powerful.</p>
        <p className="text-gray-400 mb-6">From $999 or $83.25/mo. for 12 mo.</p>
        <div className="flex justify-center space-x-4 mb-8">
          <Button className="rounded-full bg-blue-600 hover:bg-blue-700 px-8 py-4 h-auto font-medium">
            Buy
          </Button>
          <Link
            href="/"
            className="text-blue-500 hover:underline flex items-center text-lg"
          >
            Learn more <span className="ml-1">&gt;</span>
          </Link>
        </div>
        <div className="max-w-6xl mx-auto mt-10">
          <Image
            src="https://www.apple.com/v/home/cd/images/heroes/ipad-pro/hero_ipadpro__6dn1o5f1asye_large.jpg"
            alt="iPad Pro"
            width={1200}
            height={800}
            className="w-full h-auto"
            priority
          />
        </div>
      </section>

      {/* iPad Lineup Section */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12">
            Which iPad is right for you?
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* iPad Pro */}
            <div className="border border-gray-200 rounded-xl p-6 text-center">
              <div className="h-64 mb-6 flex items-center justify-center">
                <Image
                  src="https://www.apple.com/v/home/cd/images/heroes/ipad-pro/hero_ipadpro__6dn1o5f1asye_large.jpg"
                  alt="iPad Pro"
                  width={180}
                  height={220}
                  className="h-full w-auto object-contain"
                />
              </div>
              <h3 className="text-2xl font-semibold mb-2">iPad Pro</h3>
              <p className="text-xl text-gray-500 mb-1">The ultimate iPad experience.</p>
              <p className="text-xl text-gray-500 mb-4">M4 chip.</p>
              <p className="font-semibold mb-2">From $999</p>
              <div className="flex flex-col items-center gap-3">
                <Button className="w-full rounded-full bg-blue-600 hover:bg-blue-700">
                  Buy
                </Button>
                <Link
                  href="/"
                  className="text-blue-500 hover:underline"
                >
                  Learn more &gt;
                </Link>
              </div>
            </div>

            {/* iPad Air */}
            <div className="border border-gray-200 rounded-xl p-6 text-center">
              <div className="h-64 mb-6 flex items-center justify-center">
                <Image
                  src="https://ext.same-assets.com/3764203099.png"
                  alt="iPad Air"
                  width={180}
                  height={220}
                  className="h-full w-auto object-contain"
                />
              </div>
              <h3 className="text-2xl font-semibold mb-2">iPad Air</h3>
              <p className="text-xl text-gray-500 mb-1">Serious performance.</p>
              <p className="text-xl text-gray-500 mb-4">M2 chip.</p>
              <p className="font-semibold mb-2">From $599</p>
              <div className="flex flex-col items-center gap-3">
                <Button className="w-full rounded-full bg-blue-600 hover:bg-blue-700">
                  Buy
                </Button>
                <Link
                  href="/"
                  className="text-blue-500 hover:underline"
                >
                  Learn more &gt;
                </Link>
              </div>
            </div>

            {/* iPad (10th generation) */}
            <div className="border border-gray-200 rounded-xl p-6 text-center">
              <div className="h-64 mb-6 flex items-center justify-center">
                <Image
                  src="https://ext.same-assets.com/3764203099.png"
                  alt="iPad"
                  width={180}
                  height={220}
                  className="h-full w-auto object-contain"
                />
              </div>
              <h3 className="text-2xl font-semibold mb-2">iPad</h3>
              <p className="text-xl text-gray-500 mb-1">Colorfully capable.</p>
              <p className="text-xl text-gray-500 mb-4">A14 Bionic chip.</p>
              <p className="font-semibold mb-2">From $449</p>
              <div className="flex flex-col items-center gap-3">
                <Button className="w-full rounded-full bg-blue-600 hover:bg-blue-700">
                  Buy
                </Button>
                <Link
                  href="/"
                  className="text-blue-500 hover:underline"
                >
                  Learn more &gt;
                </Link>
              </div>
            </div>

            {/* iPad mini */}
            <div className="border border-gray-200 rounded-xl p-6 text-center">
              <div className="h-64 mb-6 flex items-center justify-center">
                <Image
                  src="https://ext.same-assets.com/3764203099.png"
                  alt="iPad mini"
                  width={150}
                  height={190}
                  className="h-full w-auto object-contain"
                />
              </div>
              <h3 className="text-2xl font-semibold mb-2">iPad mini</h3>
              <p className="text-xl text-gray-500 mb-1">Portable power.</p>
              <p className="text-xl text-gray-500 mb-4">A15 Bionic chip.</p>
              <p className="font-semibold mb-2">From $499</p>
              <div className="flex flex-col items-center gap-3">
                <Button className="w-full rounded-full bg-blue-600 hover:bg-blue-700">
                  Buy
                </Button>
                <Link
                  href="/"
                  className="text-blue-500 hover:underline"
                >
                  Learn more &gt;
                </Link>
              </div>
            </div>
          </div>

          <div className="mt-16 text-center">
            <Link
              href="/ipad/compare"
              className="text-blue-500 hover:underline text-lg"
            >
              Compare all iPad models &gt;
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 bg-black text-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12">
            What makes an iPad an iPad?
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-semibold mb-4">A complete iPad experience</h3>
              <p className="text-gray-400 mb-6">
                Every iPad combines incredible performance with advanced features like Center Stage, Apple Pay, and seamless ecosystem connectivity with your other Apple devices.
              </p>
              <Link
                href="/"
                className="text-blue-500 hover:underline"
              >
                Learn more about what makes iPad special &gt;
              </Link>
            </div>
            <div>
              <Image
                src="https://www.apple.com/v/home/cd/images/heroes/ipad-pro/hero_ipadpro__6dn1o5f1asye_large.jpg"
                alt="iPad Features"
                width={600}
                height={400}
                className="rounded-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* iPadOS Section */}
      <section className="py-16 px-4 bg-gradient-to-b from-blue-900 to-indigo-900 text-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">iPadOS</h2>
            <p className="text-xl">
              Incredibly capable. Phenomenally powerful. Impossibly magical.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-2xl font-semibold mb-4">iPadOS 17</h3>
              <p className="text-gray-300 mb-6">
                iPadOS 17 brings new levels of personalization and capability to iPad. Customize the Lock Screen with all-new interactive widgets. Write on PDFs with Apple Pencil, right in apps. Experience enhancements to Messages, FaceTime, and more.
              </p>
              <Link
                href="/"
                className="text-blue-300 hover:text-blue-200 hover:underline"
              >
                Learn more about iPadOS 17 &gt;
              </Link>
            </div>
            <div>
              <Image
                src="https://www.apple.com/v/ipad/home/cn/images/overview/ipados17/ipados17_features__e7s2j1qhvtea_large.jpg"
                alt="iPadOS 17"
                width={600}
                height={400}
                className="rounded-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Accessories Section */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12">
            iPad accessories
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Apple Pencil */}
            <div className="text-center">
              <div className="mb-6 h-48 flex items-center justify-center">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/apple-pencil-pro-202403?wid=400&hei=400&fmt=jpeg&qlt=95&.v=1707764267648"
                  alt="Apple Pencil"
                  width={200}
                  height={200}
                  className="h-full w-auto object-contain"
                />
              </div>
              <h3 className="text-2xl font-semibold mb-2">Apple Pencil</h3>
              <p className="text-gray-600 mb-4">Dream it up. Jot it down.</p>
              <Link
                href="/"
                className="text-blue-500 hover:underline"
              >
                Shop &gt;
              </Link>
            </div>

            {/* Magic Keyboard */}
            <div className="text-center">
              <div className="mb-6 h-48 flex items-center justify-center">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/MPME3?wid=400&hei=400&fmt=jpeg&qlt=95&.v=1666123999266"
                  alt="Magic Keyboard"
                  width={200}
                  height={200}
                  className="h-full w-auto object-contain"
                />
              </div>
              <h3 className="text-2xl font-semibold mb-2">Magic Keyboard</h3>
              <p className="text-gray-600 mb-4">A distinctive typing experience.</p>
              <Link
                href="/"
                className="text-blue-500 hover:underline"
              >
                Shop &gt;
              </Link>
            </div>

            {/* Smart Folio */}
            <div className="text-center">
              <div className="mb-6 h-48 flex items-center justify-center">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/MPPX3?wid=400&hei=400&fmt=jpeg&qlt=95&.v=1693594421686"
                  alt="Smart Folio"
                  width={200}
                  height={200}
                  className="h-full w-auto object-contain"
                />
              </div>
              <h3 className="text-2xl font-semibold mb-2">Smart Folio</h3>
              <p className="text-gray-600 mb-4">Protection and style in a range of colors.</p>
              <Link
                href="/"
                className="text-blue-500 hover:underline"
              >
                Shop &gt;
              </Link>
            </div>
          </div>

          <div className="text-center mt-12">
            <Button className="rounded-full bg-blue-600 hover:bg-blue-700 px-8 py-3 font-medium">
              Shop all iPad accessories
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 bg-gray-100">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">The perfect iPad for you</h2>
          <p className="text-xl text-gray-600 mb-8">
            From premium performance to everyday versatility, there's an iPad for everything you love to do.
          </p>
          <Button className="rounded-full bg-blue-600 hover:bg-blue-700 px-8 py-4 text-lg font-medium">
            Shop iPad
          </Button>
        </div>
      </section>
    </div>
  );
}
