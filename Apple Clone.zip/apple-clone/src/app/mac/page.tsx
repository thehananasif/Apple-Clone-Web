"use client";

import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";

export default function MacPage() {
  return (
    <div className="w-full pt-12">
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-gray-100 to-white text-black py-16 px-4 text-center">
        <h1 className="text-5xl sm:text-6xl font-bold mb-4">Mac</h1>
        <p className="text-xl sm:text-2xl mb-10 max-w-3xl mx-auto">
          Get to know Mac.
        </p>

        <div className="flex flex-wrap justify-center gap-6 mb-12">
          <Link href="#macbook-air" className="text-blue-500 hover:underline">
            MacBook Air
          </Link>
          <Link href="#macbook-pro" className="text-blue-500 hover:underline">
            MacBook Pro
          </Link>
          <Link href="#imac" className="text-blue-500 hover:underline">
            iMac
          </Link>
          <Link href="#mac-mini" className="text-blue-500 hover:underline">
            Mac Mini
          </Link>
          <Link href="#mac-studio" className="text-blue-500 hover:underline">
            Mac Studio
          </Link>
          <Link href="#mac-pro" className="text-blue-500 hover:underline">
            Mac Pro
          </Link>
          <Link href="#compare" className="text-blue-500 hover:underline">
            Compare
          </Link>
          <Link href="#accessories" className="text-blue-500 hover:underline">
            Accessories
          </Link>
          <Link href="#macos" className="text-blue-500 hover:underline">
            macOS
          </Link>
        </div>

        <Image
          src="https://ext.same-assets.com/3295842111/3485052049.jpeg"
          alt="Mac Lineup"
          width={1200}
          height={600}
          className="w-full max-w-6xl h-auto mx-auto rounded-xl"
          priority
        />
      </section>

      {/* Help Me Choose Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-semibold text-center mb-12">
            Help me choose.
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gray-50 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
              <Image
                src="https://ext.same-assets.com/3295842111/442059837.svg"
                alt="Compare Mac Models"
                width={300}
                height={200}
                className="w-full h-auto"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">
                  Compare all Mac models
                </h3>
                <p className="text-gray-600 mb-4">
                  Find the best Mac for your needs.
                </p>
                <Link
                  href="#compare"
                  className="text-blue-500 hover:underline flex items-center"
                >
                  Compare <span className="ml-1">&gt;</span>
                </Link>
              </div>
            </div>

            <div className="bg-gray-50 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
              <Image
                src="https://ext.same-assets.com/3295842111/1903966855.svg"
                alt="Why Mac"
                width={300}
                height={200}
                className="w-full h-auto"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">Why Mac</h3>
                <p className="text-gray-600 mb-4">
                  Incredible performance, designed together.
                </p>
                <Link
                  href="#why-mac"
                  className="text-blue-500 hover:underline flex items-center"
                >
                  Learn more <span className="ml-1">&gt;</span>
                </Link>
              </div>
            </div>

            <div className="bg-gray-50 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
              <Image
                src="https://ext.same-assets.com/3295842111/2213456062.svg"
                alt="Shop Mac"
                width={300}
                height={200}
                className="w-full h-auto"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">Shop Mac</h3>
                <p className="text-gray-600 mb-4">
                  Find the perfect Mac for you.
                </p>
                <Link
                  href="/store"
                  className="text-blue-500 hover:underline flex items-center"
                >
                  Shop <span className="ml-1">&gt;</span>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* MacBook Air Section */}
      <section id="macbook-air" className="py-20 px-4 bg-[#f5f5f7]">
        <div className="max-w-6xl mx-auto">
          <Image
            src="https://ext.same-assets.com/3295842111/1053447418.svg"
            alt="MacBook Air"
            width={80}
            height={54}
            className="h-14 w-auto mx-auto mb-4"
          />

          <div className="text-center mb-10">
            <h2 className="text-4xl font-semibold mb-4">MacBook Air</h2>
            <p className="text-xl text-gray-600">
              Sky blue color. Sky high performance with M4.
            </p>
            <p className="text-lg mt-2">From $999</p>
            <div className="flex justify-center mt-4 space-x-4">
              <Button className="rounded-full bg-blue-600 hover:bg-blue-700 px-6">
                Buy
              </Button>
              <Link
                href="/macbook-air"
                className="text-blue-500 hover:underline flex items-center"
              >
                Learn more <span className="ml-1">&gt;</span>
              </Link>
            </div>
          </div>

          <div className="mt-8">
            <Image
              src="https://ext.same-assets.com/904505210/702855466.png"
              alt="MacBook Air"
              width={1000}
              height={600}
              className="w-full h-auto mx-auto"
            />
          </div>
        </div>
      </section>

      {/* MacBook Pro Section */}
      <section id="macbook-pro" className="py-20 px-4 bg-black text-white">
        <div className="max-w-6xl mx-auto">
          <Image
            src="https://ext.same-assets.com/3295842111/1816588255.svg"
            alt="MacBook Pro"
            width={80}
            height={54}
            className="h-14 w-auto mx-auto mb-4 invert"
          />

          <div className="text-center mb-10">
            <h2 className="text-4xl font-semibold mb-4">MacBook Pro</h2>
            <p className="text-xl text-gray-400">
              A work of smart.
            </p>
            <p className="text-lg mt-2">From $1599</p>
            <div className="flex justify-center mt-4 space-x-4">
              <Button className="rounded-full bg-blue-600 hover:bg-blue-700 px-6">
                Buy
              </Button>
              <Link
                href="/macbook-pro"
                className="text-blue-500 hover:underline flex items-center"
              >
                Learn more <span className="ml-1">&gt;</span>
              </Link>
            </div>
          </div>

          <div className="mt-8">
            <Image
              src="https://www.apple.com/v/mac/home/cg/images/overview/hero_macbook_pro__f5vmmy2j6vqu_large.jpg"
              alt="MacBook Pro"
              width={1000}
              height={600}
              className="w-full h-auto mx-auto"
            />
          </div>
        </div>
      </section>

      {/* iMac Section */}
      <section id="imac" className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <Image
            src="https://ext.same-assets.com/3295842111/3529575197.svg"
            alt="iMac"
            width={80}
            height={54}
            className="h-14 w-auto mx-auto mb-4"
          />

          <div className="text-center mb-10">
            <h2 className="text-4xl font-semibold mb-4">iMac</h2>
            <p className="text-xl text-gray-600">
              Packed with more pixels. Powered by M3.
            </p>
            <p className="text-lg mt-2">From $1299</p>
            <div className="flex justify-center mt-4 space-x-4">
              <Button className="rounded-full bg-blue-600 hover:bg-blue-700 px-6">
                Buy
              </Button>
              <Link
                href="/imac"
                className="text-blue-500 hover:underline flex items-center"
              >
                Learn more <span className="ml-1">&gt;</span>
              </Link>
            </div>
          </div>

          <div className="mt-8">
            <Image
              src="https://www.apple.com/v/mac/home/cg/images/overview/hero_imac_m3__ers9jfwcyxie_large.jpg"
              alt="iMac"
              width={1000}
              height={600}
              className="w-full h-auto mx-auto"
            />
          </div>
        </div>
      </section>

      {/* Mac mini Section */}
      <section id="mac-mini" className="py-20 px-4 bg-[#f5f5f7]">
        <div className="max-w-6xl mx-auto">
          <Image
            src="https://ext.same-assets.com/3295842111/3283903128.svg"
            alt="Mac mini"
            width={80}
            height={54}
            className="h-14 w-auto mx-auto mb-4"
          />

          <div className="text-center mb-10">
            <h2 className="text-4xl font-semibold mb-4">Mac mini</h2>
            <p className="text-xl text-gray-600">
              More muscle. More boom.
            </p>
            <p className="text-lg mt-2">From $599</p>
            <div className="flex justify-center mt-4 space-x-4">
              <Button className="rounded-full bg-blue-600 hover:bg-blue-700 px-6">
                Buy
              </Button>
              <Link
                href="/mac-mini"
                className="text-blue-500 hover:underline flex items-center"
              >
                Learn more <span className="ml-1">&gt;</span>
              </Link>
            </div>
          </div>

          <div className="mt-8">
            <Image
              src="https://www.apple.com/v/mac/home/cg/images/overview/hero_mac_mini__2s0dtqbqf9em_large.jpg"
              alt="Mac mini"
              width={1000}
              height={600}
              className="w-full h-auto mx-auto"
            />
          </div>
        </div>
      </section>

      {/* Mac Studio Section */}
      <section id="mac-studio" className="py-20 px-4 bg-black text-white">
        <div className="max-w-6xl mx-auto">
          <Image
            src="https://ext.same-assets.com/3295842111/2518381853.svg"
            alt="Mac Studio"
            width={80}
            height={54}
            className="h-14 w-auto mx-auto mb-4 invert"
          />

          <div className="text-center mb-10">
            <h2 className="text-4xl font-semibold mb-4">Mac Studio</h2>
            <p className="text-xl text-gray-400">
              Supercharged by M2 Max and M2 Ultra.
            </p>
            <p className="text-lg mt-2">From $1999</p>
            <div className="flex justify-center mt-4 space-x-4">
              <Button className="rounded-full bg-blue-600 hover:bg-blue-700 px-6">
                Buy
              </Button>
              <Link
                href="/mac-studio"
                className="text-blue-500 hover:underline flex items-center"
              >
                Learn more <span className="ml-1">&gt;</span>
              </Link>
            </div>
          </div>

          <div className="mt-8">
            <Image
              src="https://www.apple.com/v/mac/home/cg/images/overview/hero_mac_studio__ehkp0h3xgjuq_large.jpg"
              alt="Mac Studio"
              width={1000}
              height={600}
              className="w-full h-auto mx-auto"
            />
          </div>
        </div>
      </section>

      {/* Mac Pro Section */}
      <section id="mac-pro" className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <Image
            src="https://ext.same-assets.com/3295842111/174309959.svg"
            alt="Mac Pro"
            width={80}
            height={54}
            className="h-14 w-auto mx-auto mb-4"
          />

          <div className="text-center mb-10">
            <h2 className="text-4xl font-semibold mb-4">Mac Pro</h2>
            <p className="text-xl text-gray-600">
              Power to change everything.
            </p>
            <p className="text-lg mt-2">From $6999</p>
            <div className="flex justify-center mt-4 space-x-4">
              <Button className="rounded-full bg-blue-600 hover:bg-blue-700 px-6">
                Buy
              </Button>
              <Link
                href="/mac-pro"
                className="text-blue-500 hover:underline flex items-center"
              >
                Learn more <span className="ml-1">&gt;</span>
              </Link>
            </div>
          </div>

          <div className="mt-8">
            <Image
              src="https://www.apple.com/v/mac/home/cg/images/overview/hero_mac_pro__5dr4d6vpxy66_large.jpg"
              alt="Mac Pro"
              width={1000}
              height={600}
              className="w-full h-auto mx-auto"
            />
          </div>
        </div>
      </section>

      {/* macOS Section */}
      <section id="macos" className="py-20 px-4 bg-gradient-to-b from-blue-900 to-blue-700 text-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-5xl font-semibold mb-4">macOS</h2>
            <p className="text-xl">
              Incredible power. Incredibly simple.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <div>
              <h3 className="text-3xl font-semibold mb-4">macOS Sequoia</h3>
              <p className="text-gray-200 mb-6">
                With macOS Sequoia, your Mac is more responsive, capable, and reliable than ever. New features like window tiling, intelligent summaries, and video recording transcripts help you work smarter. And with a refreshed design, everything feels more focused and organized.
              </p>
              <Link
                href="/macos"
                className="text-blue-300 hover:text-blue-200 hover:underline flex items-center"
              >
                Learn more about macOS Sequoia <span className="ml-1">&gt;</span>
              </Link>
            </div>
            <div>
              <Image
                src="https://ext.same-assets.com/3295842111/2721893915.svg"
                alt="macOS"
                width={600}
                height={400}
                className="w-full h-auto mx-auto rounded-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Compare Section */}
      <section id="compare" className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-semibold text-center mb-16">
            Compare Mac models
          </h2>

          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead>
                <tr>
                  <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Model
                  </th>
                  <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Chip
                  </th>
                  <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Display
                  </th>
                  <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Memory
                  </th>
                  <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Storage
                  </th>
                  <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Battery
                  </th>
                  <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Price
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    MacBook Air 13"
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    M4
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    13.6" Liquid Retina
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Up to 24GB
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Up to 2TB
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Up to 18 hours
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    From $999
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    MacBook Air 15"
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    M4
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    15.3" Liquid Retina
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Up to 24GB
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Up to 2TB
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Up to 18 hours
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    From $1299
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    MacBook Pro 14"
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    M3, M3 Pro, or M3 Max
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    14.2" Liquid Retina XDR
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Up to 128GB
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Up to 8TB
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Up to 22 hours
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    From $1599
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    MacBook Pro 16"
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    M3 Pro or M3 Max
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    16.2" Liquid Retina XDR
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Up to 128GB
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Up to 8TB
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Up to 24 hours
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    From $2499
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="text-center mt-12">
            <Link
              href="/compare-mac"
              className="text-blue-500 hover:underline text-lg"
            >
              View full comparison
            </Link>
          </div>
        </div>
      </section>

      {/* Accessories Section */}
      <section id="accessories" className="py-20 px-4 bg-[#f5f5f7]">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-semibold text-center mb-12">
            Accessories
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Accessory 1 */}
            <div className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow p-6 text-center">
              <Image
                src="https://ext.same-assets.com/3295842111/1242778139.svg"
                alt="Displays"
                width={60}
                height={60}
                className="h-16 w-auto mx-auto mb-4"
              />
              <h3 className="text-xl font-semibold mb-2">Displays</h3>
              <p className="text-gray-600 mb-4">
                Stunning screens for your Mac.
              </p>
              <Link
                href="/accessories/displays"
                className="text-blue-500 hover:underline"
              >
                Shop displays &gt;
              </Link>
            </div>

            {/* Accessory 2 */}
            <div className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow p-6 text-center">
              <Image
                src="https://ext.same-assets.com/3295842111/1242778139.svg"
                alt="Magic Keyboards"
                width={60}
                height={60}
                className="h-16 w-auto mx-auto mb-4"
              />
              <h3 className="text-xl font-semibold mb-2">Magic Keyboards</h3>
              <p className="text-gray-600 mb-4">
                Wireless keyboards with a perfect feel.
              </p>
              <Link
                href="/accessories/keyboards"
                className="text-blue-500 hover:underline"
              >
                Shop keyboards &gt;
              </Link>
            </div>

            {/* Accessory 3 */}
            <div className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow p-6 text-center">
              <Image
                src="https://ext.same-assets.com/3295842111/1242778139.svg"
                alt="Trackpads & Mice"
                width={60}
                height={60}
                className="h-16 w-auto mx-auto mb-4"
              />
              <h3 className="text-xl font-semibold mb-2">Trackpads & Mice</h3>
              <p className="text-gray-600 mb-4">
                Wireless precision control.
              </p>
              <Link
                href="/accessories/trackpads-mice"
                className="text-blue-500 hover:underline"
              >
                Shop trackpads & mice &gt;
              </Link>
            </div>
          </div>

          <div className="text-center mt-12">
            <Button className="rounded-full bg-blue-600 hover:bg-blue-700 px-8">
              Shop all Mac accessories
            </Button>
          </div>
        </div>
      </section>

      {/* Ways to Buy Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-semibold text-center mb-12">
            Ways to buy
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-semibold mb-4">Apple Store</h3>
              <p className="text-gray-600 mb-4">
                Visit an Apple Store and get help from a Specialist.
              </p>
              <Link
                href="/retail"
                className="text-blue-500 hover:underline flex items-center"
              >
                Find a store <span className="ml-1">&gt;</span>
              </Link>
            </div>
            <div>
              <h3 className="text-2xl font-semibold mb-4">Apple Trade In</h3>
              <p className="text-gray-600 mb-4">
                Get credit toward a new Mac when you trade in your eligible computer.
              </p>
              <Link
                href="/trade-in"
                className="text-blue-500 hover:underline flex items-center"
              >
                Learn more <span className="ml-1">&gt;</span>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
