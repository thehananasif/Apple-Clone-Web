"use client";

import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";

export default function IPhonePage() {
  return (
    <div className="w-full pt-12">
      {/* Hero Section */}
      <section className="bg-black text-white py-16 px-4 text-center">
        <h1 className="text-5xl sm:text-6xl font-bold mb-4">iPhone 16 Pro</h1>
        <p className="text-xl sm:text-2xl mb-6">Built for Apple Intelligence.</p>
        <p className="text-gray-400 mb-6">From $999 or $41.62/mo. for 24 mo.</p>
        <div className="flex justify-center space-x-4 mb-8">
          <Button className="rounded-full bg-blue-600 hover:bg-blue-700 px-8 py-4 h-auto font-medium">
            Buy
          </Button>
          <Link
            href="/"
            className="text-blue-500 hover:underline flex items-center text-lg"
          >
            Learn more <span className="ml-1">&gt;</span>
          </Link>
        </div>
        <div className="max-w-6xl mx-auto mt-10">
          <Image
            src="https://ext.same-assets.com/4254329689/1347262668.png"
            alt="iPhone 16 Pro"
            width={1200}
            height={800}
            className="w-full h-auto"
            priority
          />
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-black text-white py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12">
            Titanium. So strong. So light. So Pro.
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-semibold mb-4">
                The most premium material ever used for iPhone
              </h3>
              <p className="text-gray-400">
                iPhone 16 Pro has a strong and light aerospace-grade titanium design. The titanium bands have a brushed texture, and the edges are polished to reflect light beautifully.
              </p>
            </div>
            <div>
              <h3 className="text-2xl font-semibold mb-4">
                Four beautiful finishes
              </h3>
              <p className="text-gray-400">
                Available in Natural Titanium, White Titanium, Black Titanium, and Desert Titanium.
              </p>
              <div className="grid grid-cols-4 gap-4 mt-6">
                <div className="flex flex-col items-center">
                  <div className="w-10 h-10 rounded-full bg-gray-200" />
                  <span className="text-xs mt-2">White</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="w-10 h-10 rounded-full bg-gray-800" />
                  <span className="text-xs mt-2">Black</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="w-10 h-10 rounded-full bg-gray-500" />
                  <span className="text-xs mt-2">Natural</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="w-10 h-10 rounded-full bg-amber-700" />
                  <span className="text-xs mt-2">Desert</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Camera Section */}
      <section className="bg-gray-900 text-white py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-8">Camera</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-2xl font-semibold mb-4">
                Pro camera system
              </h3>
              <ul className="space-y-4 text-gray-400">
                <li>- 48MP Main: 26 mm, ƒ/1.6 aperture</li>
                <li>- 12MP Ultra Wide: 13 mm, ƒ/2.2 aperture</li>
                <li>- 12MP 2x Telephoto (enabled by quad-pixel sensor): 52 mm, ƒ/1.6 aperture</li>
                <li>- 12MP 5x Telephoto: 120 mm, ƒ/2.8 aperture</li>
              </ul>
              <div className="mt-6">
                <Link
                  href="/"
                  className="text-blue-500 hover:underline flex items-center text-lg"
                >
                  See the camera in action <span className="ml-1">&gt;</span>
                </Link>
              </div>
            </div>
            <div>
              <Image
                src="https://ext.same-assets.com/4254329689/3569027670.jpeg"
                alt="iPhone Camera System"
                width={500}
                height={500}
                className="w-full h-auto rounded-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* A18 Pro Chip Section */}
      <section className="bg-black text-white py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">A18 Pro chip</h2>
          <p className="text-xl text-gray-400 mb-8">
            The fastest, most efficient chip in a smartphone, and the only smartphone chip powerful enough for Apple Intelligence.
          </p>
          <Image
            src="https://ext.same-assets.com/4254329689/2825919849.jpeg"
            alt="A18 Pro Chip"
            width={800}
            height={500}
            className="w-full h-auto rounded-xl"
          />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            <div>
              <h3 className="text-2xl font-bold mb-2">25%</h3>
              <p className="text-gray-400">
                Faster CPU performance than A17 Pro
              </p>
            </div>
            <div>
              <h3 className="text-2xl font-bold mb-2">20%</h3>
              <p className="text-gray-400">
                Faster GPU performance than A17 Pro
              </p>
            </div>
            <div>
              <h3 className="text-2xl font-bold mb-2">2x</h3>
              <p className="text-gray-400">
                Faster Neural Engine than A17 Pro
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Battery Section */}
      <section className="bg-gray-900 text-white py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">All-day battery life</h2>
          <p className="text-xl text-gray-400 mb-8">
            Even with so many advanced features, iPhone 16 Pro still gives you amazing all-day battery life.
          </p>
          <Image
            src="https://ext.same-assets.com/4254329689/531503982.jpeg"
            alt="iPhone Battery"
            width={800}
            height={500}
            className="w-full h-auto rounded-xl"
          />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12 text-left">
            <div>
              <h3 className="text-2xl font-semibold mb-4">Up to</h3>
              <p className="text-4xl font-bold text-white mb-2">29 hours</p>
              <p className="text-gray-400">
                of video playback on iPhone 16 Pro Max
              </p>
            </div>
            <div>
              <h3 className="text-2xl font-semibold mb-4">Up to</h3>
              <p className="text-4xl font-bold text-white mb-2">27 hours</p>
              <p className="text-gray-400">
                of video playback on iPhone 16 Pro
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Compare Models Section */}
      <section className="bg-white text-black py-16 px-4">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12">
            Which iPhone is right for you?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* iPhone 16 Pro Max */}
            <div className="border border-gray-200 rounded-xl p-6 text-center">
              <div className="h-48 mb-4 flex items-center justify-center">
                <Image
                  src="https://ext.same-assets.com/4254329689/475379279.jpeg"
                  alt="iPhone 16 Pro Max"
                  width={120}
                  height={240}
                  className="h-full w-auto object-contain"
                />
              </div>
              <h3 className="text-xl font-semibold mb-2">iPhone 16 Pro Max</h3>
              <p className="text-gray-500 mb-4">The ultimate iPhone.</p>
              <p className="font-semibold mb-2">From $1199</p>
              <Button className="w-full rounded-full bg-blue-600 hover:bg-blue-700">
                Buy
              </Button>
              <Link
                href="/"
                className="block mt-4 text-blue-500 hover:underline"
              >
                Learn more &gt;
              </Link>
            </div>

            {/* iPhone 16 Pro */}
            <div className="border border-gray-200 rounded-xl p-6 text-center">
              <div className="h-48 mb-4 flex items-center justify-center">
                <Image
                  src="https://ext.same-assets.com/4254329689/475379279.jpeg"
                  alt="iPhone 16 Pro"
                  width={120}
                  height={240}
                  className="h-full w-auto object-contain"
                />
              </div>
              <h3 className="text-xl font-semibold mb-2">iPhone 16 Pro</h3>
              <p className="text-gray-500 mb-4">Pro. Beyond.</p>
              <p className="font-semibold mb-2">From $999</p>
              <Button className="w-full rounded-full bg-blue-600 hover:bg-blue-700">
                Buy
              </Button>
              <Link
                href="/"
                className="block mt-4 text-blue-500 hover:underline"
              >
                Learn more &gt;
              </Link>
            </div>

            {/* iPhone 16 Plus */}
            <div className="border border-gray-200 rounded-xl p-6 text-center">
              <div className="h-48 mb-4 flex items-center justify-center">
                <Image
                  src="https://ext.same-assets.com/904505210/1225220529.jpeg"
                  alt="iPhone 16 Plus"
                  width={120}
                  height={240}
                  className="h-full w-auto object-contain"
                />
              </div>
              <h3 className="text-xl font-semibold mb-2">iPhone 16 Plus</h3>
              <p className="text-gray-500 mb-4">Big and mighty.</p>
              <p className="font-semibold mb-2">From $899</p>
              <Button className="w-full rounded-full bg-blue-600 hover:bg-blue-700">
                Buy
              </Button>
              <Link
                href="/"
                className="block mt-4 text-blue-500 hover:underline"
              >
                Learn more &gt;
              </Link>
            </div>

            {/* iPhone 16 */}
            <div className="border border-gray-200 rounded-xl p-6 text-center">
              <div className="h-48 mb-4 flex items-center justify-center">
                <Image
                  src="https://ext.same-assets.com/904505210/1225220529.jpeg"
                  alt="iPhone 16"
                  width={120}
                  height={240}
                  className="h-full w-auto object-contain"
                />
              </div>
              <h3 className="text-xl font-semibold mb-2">iPhone 16</h3>
              <p className="text-gray-500 mb-4">Powered by intelligence.</p>
              <p className="font-semibold mb-2">From $799</p>
              <Button className="w-full rounded-full bg-blue-600 hover:bg-blue-700">
                Buy
              </Button>
              <Link
                href="/"
                className="block mt-4 text-blue-500 hover:underline"
              >
                Learn more &gt;
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Accessories Section */}
      <section className="bg-gray-100 text-black py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12">
            Featured accessories
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* MagSafe Case */}
            <div className="text-center">
              <div className="mb-4 h-48 flex items-center justify-center">
                <Image
                  src="https://ext.same-assets.com/897889413/3340563565.png"
                  alt="MagSafe Case"
                  width={200}
                  height={200}
                  className="h-full w-auto object-contain"
                />
              </div>
              <h3 className="text-xl font-semibold mb-2">iPhone 16 Pro MagSafe Case</h3>
              <p className="text-gray-500 mb-4">Available in multiple colors.</p>
              <p className="font-semibold mb-4">$49.00</p>
              <Button className="rounded-full bg-blue-600 hover:bg-blue-700 px-6">
                Buy
              </Button>
            </div>

            {/* Screen Protector */}
            <div className="text-center">
              <div className="mb-4 h-48 flex items-center justify-center">
                <Image
                  src="https://ext.same-assets.com/897889413/3340563565.png"
                  alt="Screen Protector"
                  width={200}
                  height={200}
                  className="h-full w-auto object-contain"
                />
              </div>
              <h3 className="text-xl font-semibold mb-2">iPhone 16 Pro Screen Protector</h3>
              <p className="text-gray-500 mb-4">Tempered glass with easy installation.</p>
              <p className="font-semibold mb-4">$29.00</p>
              <Button className="rounded-full bg-blue-600 hover:bg-blue-700 px-6">
                Buy
              </Button>
            </div>

            {/* MagSafe Charger */}
            <div className="text-center">
              <div className="mb-4 h-48 flex items-center justify-center">
                <Image
                  src="https://ext.same-assets.com/897889413/3340563565.png"
                  alt="MagSafe Charger"
                  width={200}
                  height={200}
                  className="h-full w-auto object-contain"
                />
              </div>
              <h3 className="text-xl font-semibold mb-2">MagSafe Charger</h3>
              <p className="text-gray-500 mb-4">Fast wireless charging up to 15W.</p>
              <p className="font-semibold mb-4">$39.00</p>
              <Button className="rounded-full bg-blue-600 hover:bg-blue-700 px-6">
                Buy
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-white text-black py-16 px-4 text-center">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-4xl font-bold mb-6">Get your iPhone 16 Pro today</h2>
          <p className="text-xl text-gray-600 mb-8">
            From $999 or $41.62/mo. for 24 mo.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="rounded-full bg-blue-600 hover:bg-blue-700 px-8 py-5 h-auto text-lg">
              Buy iPhone 16 Pro
            </Button>
            <Link
              href="/"
              className="inline-flex items-center justify-center text-blue-500 hover:underline text-lg px-6 py-2"
            >
              Learn more about iPhone 16 Pro
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
