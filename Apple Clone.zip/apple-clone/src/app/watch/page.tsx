"use client";

import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";

export default function WatchPage() {
  return (
    <div className="w-full pt-12">
      {/* Hero Section */}
      <section className="bg-black text-white py-16 px-4 text-center">
        <div className="flex flex-col items-center">
          <Image
            src="https://ext.same-assets.com/904505210/702619004.jpeg"
            alt="Apple Watch Series 10"
            width={140}
            height={50}
            className="h-16 w-auto object-contain mb-6"
          />
          <h1 className="text-4xl sm:text-5xl font-semibold mb-3">Thousand classic.</h1>
          <p className="text-xl text-gray-400 mb-8 max-w-xl mx-auto">
            The most advanced Apple Watch yet, with our largest display. And a design that's beautiful and durable.
          </p>
          <p className="text-gray-400 mb-6">From $399</p>
          <div className="flex justify-center space-x-4 mb-8">
            <Button className="rounded-full bg-blue-600 hover:bg-blue-700 px-8 py-4 h-auto font-medium">
              Buy
            </Button>
            <Link
              href="/"
              className="text-blue-500 hover:underline flex items-center text-lg"
            >
              Learn more <span className="ml-1">&gt;</span>
            </Link>
          </div>
        </div>
        <div className="max-w-6xl mx-auto mt-10">
          <Image
            src="https://ext.same-assets.com/904505210/702619004.jpeg"
            alt="Apple Watch Series 10"
            width={1200}
            height={800}
            className="w-full h-auto"
            priority
          />
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-white py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-semibold text-center mb-16">
            Get the most out of your Apple Watch.
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M19 9.5a7 7 0 1 1-14 0 7 7 0 0 1 14 0Z" />
                  <path d="m12 3.5 2 2" />
                  <path d="m12 3.5-2 2" />
                  <path d="M12 13V9.5" />
                  <path d="M12 22v-5" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Advanced Health Monitoring</h3>
              <p className="text-gray-600">
                Track your health metrics with ECG, blood oxygen, and temperature sensors.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
                  <path d="M9 22V12h6v10" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Seamless Integration</h3>
              <p className="text-gray-600">
                Works perfectly with your iPhone and other Apple devices.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M8 2v4" />
                  <path d="M16 2v4" />
                  <rect width="18" height="18" x="3" y="4" rx="2" />
                  <path d="M3 10h18" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Personalized Experience</h3>
              <p className="text-gray-600">
                Customize with watch faces, apps, and bands that match your style.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Apple Watch Lineup */}
      <section className="bg-[#f5f5f7] py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-semibold text-center mb-16">
            Which Apple Watch is right for you?
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Apple Watch Series 10 */}
            <div className="bg-white rounded-xl overflow-hidden shadow-sm">
              <div className="p-8 text-center">
                <Image
                  src="https://ext.same-assets.com/904505210/702619004.jpeg"
                  alt="Apple Watch Series 10"
                  width={180}
                  height={220}
                  className="h-48 w-auto object-contain mx-auto mb-6"
                />
                <h3 className="text-2xl font-semibold mb-2">Apple Watch Series 10</h3>
                <p className="text-gray-500 mb-4">Our most advanced Apple Watch yet.</p>
                <p className="font-semibold mb-6">From $399</p>
                <div className="space-y-3">
                  <Button className="w-full rounded-full bg-blue-600 hover:bg-blue-700">
                    Buy
                  </Button>
                  <Link
                    href="/"
                    className="block text-blue-500 hover:underline"
                  >
                    Learn more &gt;
                  </Link>
                </div>
              </div>
            </div>

            {/* Apple Watch Ultra 2 */}
            <div className="bg-white rounded-xl overflow-hidden shadow-sm">
              <div className="p-8 text-center">
                <Image
                  src="https://ext.same-assets.com/904505210/702619004.jpeg"
                  alt="Apple Watch Ultra 2"
                  width={180}
                  height={220}
                  className="h-48 w-auto object-contain mx-auto mb-6"
                />
                <h3 className="text-2xl font-semibold mb-2">Apple Watch Ultra 2</h3>
                <p className="text-gray-500 mb-4">Our most rugged and capable Apple Watch.</p>
                <p className="font-semibold mb-6">From $799</p>
                <div className="space-y-3">
                  <Button className="w-full rounded-full bg-blue-600 hover:bg-blue-700">
                    Buy
                  </Button>
                  <Link
                    href="/"
                    className="block text-blue-500 hover:underline"
                  >
                    Learn more &gt;
                  </Link>
                </div>
              </div>
            </div>

            {/* Apple Watch SE */}
            <div className="bg-white rounded-xl overflow-hidden shadow-sm">
              <div className="p-8 text-center">
                <Image
                  src="https://ext.same-assets.com/904505210/702619004.jpeg"
                  alt="Apple Watch SE"
                  width={180}
                  height={220}
                  className="h-48 w-auto object-contain mx-auto mb-6"
                />
                <h3 className="text-2xl font-semibold mb-2">Apple Watch SE</h3>
                <p className="text-gray-500 mb-4">All the essentials at a more affordable price.</p>
                <p className="font-semibold mb-6">From $249</p>
                <div className="space-y-3">
                  <Button className="w-full rounded-full bg-blue-600 hover:bg-blue-700">
                    Buy
                  </Button>
                  <Link
                    href="/"
                    className="block text-blue-500 hover:underline"
                  >
                    Learn more &gt;
                  </Link>
                </div>
              </div>
            </div>
          </div>

          <div className="text-center mt-12">
            <Link
              href="/watch/compare"
              className="text-blue-500 hover:underline text-lg"
            >
              Compare all models &gt;
            </Link>
          </div>
        </div>
      </section>

      {/* watchOS Section */}
      <section className="bg-black text-white py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-semibold mb-6">watchOS 11</h2>
              <p className="text-xl text-gray-300 mb-6">
                The latest watchOS delivers innovative health features, new watch faces, and improved apps to help you stay connected, active, and healthy.
              </p>
              <Link
                href="/"
                className="text-blue-400 hover:text-blue-300 hover:underline text-lg inline-flex items-center"
              >
                Learn more about watchOS 11 <span className="ml-1">&gt;</span>
              </Link>
            </div>
            <div>
              <Image
                src="https://www.apple.com/v/watch/al/images/overview/watchos/watchos__c1y3f6uzk9sy_large.jpg"
                alt="watchOS 11"
                width={600}
                height={400}
                className="rounded-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Apple Watch Studio */}
      <section className="bg-[#f5f5f7] py-20 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-4xl font-semibold mb-6">Apple Watch Studio</h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Create your own style by selecting your preferred case and band combination.
          </p>
          <Button className="rounded-full bg-blue-600 hover:bg-blue-700 px-8 py-3 font-medium">
            Create your style
          </Button>
          <div className="mt-12">
            <Image
              src="https://www.apple.com/v/watch/al/images/overview/watch-studio/studio__c0bcqpxl1t6e_large.jpg"
              alt="Apple Watch Studio"
              width={1000}
              height={600}
              className="w-full max-w-4xl h-auto mx-auto rounded-xl"
            />
          </div>
        </div>
      </section>

      {/* Apple Watch Accessories */}
      <section className="bg-white py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-semibold text-center mb-12">
            Accessories
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Bands */}
            <div className="text-center">
              <div className="h-48 flex items-center justify-center mb-6">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/MT593_FV402?wid=1420&hei=930&fmt=png-alpha&.v=1693543264752"
                  alt="Apple Watch Bands"
                  width={200}
                  height={200}
                  className="h-full w-auto object-contain"
                />
              </div>
              <h3 className="text-2xl font-semibold mb-2">Bands</h3>
              <p className="text-gray-600 mb-4">
                Express your style with a variety of bands.
              </p>
              <Link
                href="/"
                className="text-blue-500 hover:underline"
              >
                Shop bands &gt;
              </Link>
            </div>

            {/* Chargers */}
            <div className="text-center">
              <div className="h-48 flex items-center justify-center mb-6">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/MQCH3_AV1?wid=1420&hei=930&fmt=png-alpha&.v=1665456651367"
                  alt="Apple Watch Chargers"
                  width={200}
                  height={200}
                  className="h-full w-auto object-contain"
                />
              </div>
              <h3 className="text-2xl font-semibold mb-2">Chargers</h3>
              <p className="text-gray-600 mb-4">
                Power up your Apple Watch anywhere.
              </p>
              <Link
                href="/"
                className="text-blue-500 hover:underline"
              >
                Shop chargers &gt;
              </Link>
            </div>

            {/* Cases */}
            <div className="text-center">
              <div className="h-48 flex items-center justify-center mb-6">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/MPLT3_VW_34FR+watch-49-titanium-ultra2_VW_34FR_WF_CO?wid=1400&hei=1400&trim=1%2C0&fmt=p-jpg&qlt=95&.v=1684181896766"
                  alt="Apple Watch Cases"
                  width={200}
                  height={200}
                  className="h-full w-auto object-contain"
                />
              </div>
              <h3 className="text-2xl font-semibold mb-2">Cases</h3>
              <p className="text-gray-600 mb-4">
                Protect your Apple Watch with stylish cases.
              </p>
              <Link
                href="/"
                className="text-blue-500 hover:underline"
              >
                Shop cases &gt;
              </Link>
            </div>
          </div>

          <div className="text-center mt-12">
            <Button className="rounded-full bg-blue-600 hover:bg-blue-700 px-8 py-3 font-medium">
              Shop all accessories
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-[#f5f5f7] py-16 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">Find your Apple Watch</h2>
          <p className="text-xl text-gray-600 mb-8">
            With three models to choose from, there's an Apple Watch for everyone.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="rounded-full bg-blue-600 hover:bg-blue-700 px-8 py-4 text-lg font-medium">
              Shop Apple Watch
            </Button>
            <Link
              href="/watch/compare"
              className="inline-flex items-center justify-center text-blue-500 hover:underline text-lg px-6 py-2"
            >
              Compare all models
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
