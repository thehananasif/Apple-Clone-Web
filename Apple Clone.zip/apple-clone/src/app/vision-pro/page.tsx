"use client";

import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";

export default function VisionProPage() {
  return (
    <div className="w-full pt-12">
      {/* Hero Section */}
      <section className="relative bg-black text-white py-24 px-4 overflow-hidden">
        <div className="max-w-5xl mx-auto text-center">
          <h1 className="text-5xl sm:text-7xl font-bold mb-6">Apple Vision Pro</h1>
          <p className="text-2xl text-gray-300 mb-8 max-w-3xl mx-auto">
            Welcome to the era of spatial computing.
          </p>
          <p className="text-xl text-gray-400 mb-10">From $3,499</p>
          <div className="flex justify-center space-x-6 mb-12">
            <Button className="rounded-full bg-blue-600 hover:bg-blue-700 px-10 py-6 h-auto text-lg font-medium">
              Buy
            </Button>
            <Link
              href="/"
              className="text-blue-500 hover:underline flex items-center text-lg"
            >
              Learn more <span className="ml-1">&gt;</span>
            </Link>
          </div>
          <div className="relative">
            <Image
              src="https://ext.same-assets.com/897889413/2955934388.png"
              alt="Apple Vision Pro"
              width={1200}
              height={800}
              className="w-full h-auto"
              priority
            />
          </div>
        </div>
      </section>

      {/* Features Overview Section */}
      <section className="bg-[#111] text-white py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-6">A revolutionary spatial computer</h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Apple Vision Pro seamlessly blends digital content with your physical space.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="w-16 h-16 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M2 12c0-3.36 0-5.04.654-6.324a6 6 0 0 1 2.622-2.622C6.96 2 8.64 2 12 2s5.04 0 6.324.654a6 6 0 0 1 2.622 2.622C21.6 6.96 22 8.64 22 12s-.4 5.04-1.054 6.324a6 6 0 0 1-2.622 2.622C17.04 22 15.36 22 12 22s-5.04 0-6.324-1.054a6 6 0 0 1-2.622-2.622C2 17.04 2 15.36 2 12Z" />
                  <path d="M2 12h20" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Immersive Display</h3>
              <p className="text-gray-400">
                Ultra-high-resolution display system that delivers more pixels than a 4K TV for each eye.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M7 21c0-3 2-4 3-4s3 1 3 4" />
                  <path d="M19 6.91a2.8 2.8 0 0 1-3.95 0c-.87-.83-.87-2.15 0-3 .37-.36.59-.86.59-1.41a1.5 1.5 0 0 0-3 0c0 .55.22 1.05.59 1.41.87.85.87 2.17 0 3a2.8 2.8 0 0 1-3.95 0c-.87-.83-.87-2.15 0-3 .37-.36.59-.86.59-1.41a1.5 1.5 0 0 0-3 0c0 .55.22 1.05.59 1.41.87.85.87 2.17 0 3a2.8 2.8 0 0 1-3.95 0" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Apple M2 Chip</h3>
              <p className="text-gray-400">
                Breakthrough performance in a revolutionary spatial computer that fits on your face.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M14 9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7a2 2 0 0 1 2 2Z" />
                  <path d="M21 15a2 2 0 0 1-2 2h-7a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h7a2 2 0 0 1 2 2Z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Spatial Operating System</h3>
              <p className="text-gray-400">
                visionOS is the world's first spatial operating system, controlled by your eyes, hands, and voice.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Vision Pro Tech Specs */}
      <section className="bg-black text-white py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-16">
            Technical specifications
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-semibold mb-6 text-gray-200 border-b border-gray-700 pb-2">Display</h3>
              <ul className="space-y-4 text-gray-300">
                <li className="flex">
                  <span className="text-gray-500 mr-2">•</span>
                  <span>Dual micro-OLED displays with 23 million pixels</span>
                </li>
                <li className="flex">
                  <span className="text-gray-500 mr-2">•</span>
                  <span>Wide color (P3)</span>
                </li>
                <li className="flex">
                  <span className="text-gray-500 mr-2">•</span>
                  <span>High dynamic range</span>
                </li>
                <li className="flex">
                  <span className="text-gray-500 mr-2">•</span>
                  <span>Custom Apple silicon lenses</span>
                </li>
              </ul>

              <h3 className="text-2xl font-semibold mb-6 mt-10 text-gray-200 border-b border-gray-700 pb-2">Chips</h3>
              <ul className="space-y-4 text-gray-300">
                <li className="flex">
                  <span className="text-gray-500 mr-2">•</span>
                  <span>Apple M2 chip</span>
                </li>
                <li className="flex">
                  <span className="text-gray-500 mr-2">•</span>
                  <span>16-core Neural Engine</span>
                </li>
                <li className="flex">
                  <span className="text-gray-500 mr-2">•</span>
                  <span>R1 chip for real-time sensor processing</span>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-2xl font-semibold mb-6 text-gray-200 border-b border-gray-700 pb-2">Audio</h3>
              <ul className="space-y-4 text-gray-300">
                <li className="flex">
                  <span className="text-gray-500 mr-2">•</span>
                  <span>Spatial Audio with dynamic head tracking</span>
                </li>
                <li className="flex">
                  <span className="text-gray-500 mr-2">•</span>
                  <span>Personalized Spatial Audio with audio ray tracing</span>
                </li>
                <li className="flex">
                  <span className="text-gray-500 mr-2">•</span>
                  <span>Six speakers with Spatial Audio</span>
                </li>
              </ul>

              <h3 className="text-2xl font-semibold mb-6 mt-10 text-gray-200 border-b border-gray-700 pb-2">Sensors and Cameras</h3>
              <ul className="space-y-4 text-gray-300">
                <li className="flex">
                  <span className="text-gray-500 mr-2">•</span>
                  <span>12 cameras for tracking and environmental understanding</span>
                </li>
                <li className="flex">
                  <span className="text-gray-500 mr-2">•</span>
                  <span>LiDAR Scanner</span>
                </li>
                <li className="flex">
                  <span className="text-gray-500 mr-2">•</span>
                  <span>TrueDepth camera</span>
                </li>
                <li className="flex">
                  <span className="text-gray-500 mr-2">•</span>
                  <span>IR flood illuminators</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Vision Pro Apps Section */}
      <section className="bg-gradient-to-b from-[#121212] to-black text-white py-20 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">
            Enter new worlds with visionOS
          </h2>
          <p className="text-xl text-gray-300 mb-16 max-w-3xl mx-auto">
            Experience your favorite apps in an entirely new way, with content that extends beyond the boundaries of a traditional display.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-[#1a1a1a] rounded-xl p-8 text-left">
              <h3 className="text-2xl font-semibold mb-4">Entertainment</h3>
              <p className="text-gray-400 mb-6">
                Watch movies on a screen that feels 100 feet wide. Enjoy immersive Spatial Video and photos.
              </p>
              <Image
                src="https://www.apple.com/v/apple-vision-pro/b/images/overview/entertainment/tv_update__bj0uk2nfvw2a_large.jpg"
                alt="Entertainment on Vision Pro"
                width={400}
                height={300}
                className="w-full h-auto rounded-lg"
              />
            </div>

            <div className="bg-[#1a1a1a] rounded-xl p-8 text-left">
              <h3 className="text-2xl font-semibold mb-4">Productivity</h3>
              <p className="text-gray-400 mb-6">
                Set up your ideal workspace with multiple apps displayed at any size. Use Mac Virtual Display with your Mac.
              </p>
              <Image
                src="https://www.apple.com/v/apple-vision-pro/b/images/overview/apps-experiences/mac_virtual_display__e43niyh55bqu_large.jpg"
                alt="Productivity on Vision Pro"
                width={400}
                height={300}
                className="w-full h-auto rounded-lg"
              />
            </div>

            <div className="bg-[#1a1a1a] rounded-xl p-8 text-left">
              <h3 className="text-2xl font-semibold mb-4">Gaming</h3>
              <p className="text-gray-400 mb-6">
                Play games in environments that surround you, with immersive spatial experiences and 3D audio.
              </p>
              <Image
                src="https://www.apple.com/v/apple-vision-pro/b/images/overview/apps-experiences/game_room__lj34keaakcia_large.jpg"
                alt="Gaming on Vision Pro"
                width={400}
                height={300}
                className="w-full h-auto rounded-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Accessories Section */}
      <section className="bg-white py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-16 text-black">
            Essential accessories
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="h-64 flex items-center justify-center mb-6">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/vision-battery-202401?wid=1960&hei=1460&fmt=png-alpha&.v=1701103753361"
                  alt="Battery for Vision Pro"
                  width={220}
                  height={220}
                  className="h-full w-auto object-contain"
                />
              </div>
              <h3 className="text-2xl font-semibold mb-2 text-black">Battery</h3>
              <p className="text-gray-600 mb-6">
                Up to 2 hours of use, all day when plugged in.
              </p>
              <p className="font-semibold text-black mb-4">$199</p>
              <Button className="rounded-full bg-blue-600 hover:bg-blue-700">
                Buy
              </Button>
            </div>

            <div className="text-center">
              <div className="h-64 flex items-center justify-center mb-6">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/vision-travel-case-202401?wid=1960&hei=1460&fmt=png-alpha&.v=1701103505316"
                  alt="Travel Case for Vision Pro"
                  width={220}
                  height={220}
                  className="h-full w-auto object-contain"
                />
              </div>
              <h3 className="text-2xl font-semibold mb-2 text-black">Travel Case</h3>
              <p className="text-gray-600 mb-6">
                Protection and portability for your Vision Pro.
              </p>
              <p className="font-semibold text-black mb-4">$199</p>
              <Button className="rounded-full bg-blue-600 hover:bg-blue-700">
                Buy
              </Button>
            </div>

            <div className="text-center">
              <div className="h-64 flex items-center justify-center mb-6">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/vision-sol-reader-insert-202401?wid=1960&hei=1460&fmt=png-alpha&.v=1702054552712"
                  alt="Optical Inserts for Vision Pro"
                  width={220}
                  height={220}
                  className="h-full w-auto object-contain"
                />
              </div>
              <h3 className="text-2xl font-semibold mb-2 text-black">ZEISS Optical Inserts</h3>
              <p className="text-gray-600 mb-6">
                Custom lens inserts for your vision needs.
              </p>
              <p className="font-semibold text-black mb-4">$99 - $149</p>
              <Button className="rounded-full bg-blue-600 hover:bg-blue-700">
                Buy
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-black text-white py-24 px-4 text-center">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-5xl font-bold mb-6">Experience Apple Vision Pro</h2>
          <p className="text-xl text-gray-300 mb-12 max-w-3xl mx-auto">
            Discover a revolutionary spatial computer that transforms how you work, connect, and play. Order now or visit an Apple Store for a demo.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Button className="rounded-full bg-blue-600 hover:bg-blue-700 px-10 py-5 h-auto text-lg font-medium">
              Order now
            </Button>
            <Button variant="outline" className="rounded-full border-white text-white hover:bg-white/10 px-10 py-5 h-auto text-lg font-medium">
              Book a demo
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
