"use client";

import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";

const ProductCard = ({
  imageSrc,
  alt,
  title,
  href,
}: {
  imageSrc: string;
  alt: string;
  title: string;
  href: string;
}) => {
  return (
    <Link href={href} className="flex flex-col items-center group">
      <div className="w-20 h-20 mb-2 rounded-xl bg-[#f5f5f7] flex items-center justify-center">
        <Image
          src={imageSrc}
          alt={alt}
          width={60}
          height={60}
          className="w-14 h-14 object-contain"
        />
      </div>
      <span className="text-xs text-center group-hover:text-blue-500">
        {title}
      </span>
    </Link>
  );
};

const FeaturedCard = ({
  title,
  description,
  imageSrc,
  imageAlt,
  dark = false,
  newLabel = false,
  href = "/",
}: {
  title: string;
  description: string;
  imageSrc: string;
  imageAlt: string;
  dark?: boolean;
  newLabel?: boolean;
  href?: string;
}) => {
  return (
    <Link
      href={href}
      className={`block rounded-xl overflow-hidden ${
        dark ? "bg-black text-white" : "bg-white text-black"
      } group`}
    >
      <div className="p-6 pb-2">
        {newLabel && (
          <span className="inline-block mb-2 text-xs uppercase font-semibold text-blue-500">
            New
          </span>
        )}
        <h3 className="text-2xl font-semibold mb-1">{title}</h3>
        <p className={dark ? "text-gray-400" : "text-gray-500"}>{description}</p>
      </div>
      <div className="pt-2 px-6 pb-6">
        <span className="text-blue-500 group-hover:underline">Shop &gt;</span>
      </div>
      <div className="px-6 py-4">
        <Image
          src={imageSrc}
          alt={imageAlt}
          width={400}
          height={300}
          className="w-full h-auto object-contain"
        />
      </div>
    </Link>
  );
};

export default function StorePage() {
  return (
    <div className="w-full pt-12">
      {/* Hero Section */}
      <section className="bg-white px-4 py-12">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-4xl font-bold mb-6">Store</h1>
          <p className="text-xl text-gray-600 mb-8">
            The best way to buy the products you love.
          </p>

          {/* Product Navigation */}
          <div className="grid grid-cols-5 sm:grid-cols-8 md:grid-cols-10 gap-6 px-6 py-4">
            <ProductCard
              imageSrc="https://ext.same-assets.com/897889413/765411629.png"
              alt="Mac"
              title="Mac"
              href="/mac"
            />
            <ProductCard
              imageSrc="https://ext.same-assets.com/897889413/1546069203.png"
              alt="iPhone"
              title="iPhone"
              href="/iphone"
            />
            <ProductCard
              imageSrc="https://ext.same-assets.com/897889413/3764203099.png"
              alt="iPad"
              title="iPad"
              href="/ipad"
            />
            <ProductCard
              imageSrc="https://ext.same-assets.com/897889413/3115756737.png"
              alt="Apple Watch"
              title="Apple Watch"
              href="/watch"
            />
            <ProductCard
              imageSrc="https://ext.same-assets.com/897889413/1504764781.png"
              alt="AirPods"
              title="AirPods"
              href="/airpods"
            />
            <ProductCard
              imageSrc="https://ext.same-assets.com/897889413/2281717150.png"
              alt="Apple TV"
              title="Apple TV"
              href="/tv"
            />
            <ProductCard
              imageSrc="https://ext.same-assets.com/897889413/1030540288.png"
              alt="HomePod"
              title="HomePod"
              href="/homepod"
            />
            <ProductCard
              imageSrc="https://ext.same-assets.com/897889413/3783036624.png"
              alt="AirTag"
              title="AirTag"
              href="/airtag"
            />
            <ProductCard
              imageSrc="https://ext.same-assets.com/897889413/3340563565.png"
              alt="Accessories"
              title="Accessories"
              href="/accessories"
            />
            <ProductCard
              imageSrc="https://ext.same-assets.com/897889413/2955934388.png"
              alt="Vision Pro"
              title="Vision Pro"
              href="/vision-pro"
            />
          </div>
        </div>
      </section>

      {/* Latest Products Section */}
      <section className="bg-[#f5f5f7] px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-2xl font-semibold mb-6">
            The latest. Take a look at what's new, right now.
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <FeaturedCard
              title="iPhone 16 Pro"
              description="Built for Apple Intelligence."
              imageSrc="https://ext.same-assets.com/4254329689/475379279.jpeg"
              imageAlt="iPhone 16 Pro"
              dark={true}
              newLabel={true}
              href="/iphone"
            />
            <FeaturedCard
              title="MacBook Air"
              description="Sky blue color. Sky high performance with M4."
              imageSrc="https://ext.same-assets.com/904505210/702855466.png"
              imageAlt="MacBook Air"
              newLabel={true}
              href="/mac"
            />
            <FeaturedCard
              title="iPad Air"
              description="Light. Bright. Full of might."
              imageSrc="https://ext.same-assets.com/897889413/3764203099.png"
              imageAlt="iPad Air"
              newLabel={true}
              href="/ipad"
            />
          </div>
        </div>
      </section>

      {/* Help Section */}
      <section className="bg-white px-4 py-12">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-2xl font-semibold mb-8">
            Help is here. Whenever and however you need it.
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Specialist Card */}
            <div className="bg-[#f5f5f7] rounded-xl p-6 flex">
              <div className="mr-4">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/store-chat-earth-day-specialist-icon-202504_AV3?wid=70&hei=70&fmt=jpeg&qlt=90&.v=1742997161911"
                  alt="Apple Specialist"
                  width={70}
                  height={70}
                  className="rounded-full"
                />
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-1">
                  Shop with a Specialist
                </h3>
                <p className="text-gray-600 mb-3">
                  Get expert advice online, in a store, or at your door.
                </p>
                <Link
                  href="/"
                  className="text-blue-500 hover:underline"
                >
                  Connect with a Specialist &gt;
                </Link>
              </div>
            </div>

            {/* Apple Store App Card */}
            <div className="bg-[#f5f5f7] rounded-xl p-6 flex">
              <div className="mr-4">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/store-chat-specialist-icon-202309_AV2?wid=70&hei=70&fmt=jpeg&qlt=90&.v=1701194050437"
                  alt="Apple Store App"
                  width={70}
                  height={70}
                  className="rounded-full"
                />
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-1">
                  Download the Apple Store app
                </h3>
                <p className="text-gray-600 mb-3">
                  Shop with ease and get personalized recommendations.
                </p>
                <Link
                  href="/"
                  className="text-blue-500 hover:underline"
                >
                  Download now &gt;
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Apple Store Difference */}
      <section className="bg-[#f5f5f7] px-4 py-12">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-2xl font-semibold mb-8">
            The Apple Store difference. Even more reasons to shop with us.
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {/* Free Delivery */}
            <div className="bg-white rounded-xl p-6 text-center">
              <div className="w-12 h-12 bg-[#e8e8ed] rounded-full flex items-center justify-center mx-auto mb-4">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11h-4v4h-2v-4H7v-2h4V7h2v4h4v2z" fill="#1d1d1f"/>
                </svg>
              </div>
              <h3 className="text-md font-semibold mb-1">
                Enjoy free delivery
              </h3>
              <p className="text-sm text-gray-600 mb-3">
                Or pick up at an Apple Store.
              </p>
              <Link
                href="/"
                className="text-sm text-blue-500 hover:underline"
              >
                Learn more &gt;
              </Link>
            </div>

            {/* Apple Trade In */}
            <div className="bg-white rounded-xl p-6 text-center">
              <div className="w-12 h-12 bg-[#e8e8ed] rounded-full flex items-center justify-center mx-auto mb-4">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M15.55 13c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.37-.66-.11-1.48-.87-1.48H5.21l-.94-2H1v2h2l3.6 7.59-1.35 2.44C4.52 15.37 5.48 17 7 17h12v-2H7l1.1-2h7.45zM6.16 6h12.15l-2.76 5H8.53L6.16 6zM7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zm10 0c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2z" fill="#1d1d1f"/>
                </svg>
              </div>
              <h3 className="text-md font-semibold mb-1">
                Trade in your current device
              </h3>
              <p className="text-sm text-gray-600 mb-3">
                Get credit toward a new one.
              </p>
              <Link
                href="/"
                className="text-sm text-blue-500 hover:underline"
              >
                Learn more &gt;
              </Link>
            </div>

            {/* Pay Monthly */}
            <div className="bg-white rounded-xl p-6 text-center">
              <div className="w-12 h-12 bg-[#e8e8ed] rounded-full flex items-center justify-center mx-auto mb-4">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M20 4H4c-1.11 0-1.99.89-1.99 2L2 18c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z" fill="#1d1d1f"/>
                </svg>
              </div>
              <h3 className="text-md font-semibold mb-1">
                Pay monthly at 0% APR
              </h3>
              <p className="text-sm text-gray-600 mb-3">
                Choose the payment option that works for you.
              </p>
              <Link
                href="/"
                className="text-sm text-blue-500 hover:underline"
              >
                Learn more &gt;
              </Link>
            </div>

            {/* Personal Session */}
            <div className="bg-white rounded-xl p-6 text-center">
              <div className="w-12 h-12 bg-[#e8e8ed] rounded-full flex items-center justify-center mx-auto mb-4">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" fill="#1d1d1f"/>
                </svg>
              </div>
              <h3 className="text-md font-semibold mb-1">
                Get to know your new device
              </h3>
              <p className="text-sm text-gray-600 mb-3">
                Book a personal session with a Specialist.
              </p>
              <Link
                href="/"
                className="text-sm text-blue-500 hover:underline"
              >
                Learn more &gt;
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Special Stores Section */}
      <section className="bg-white px-4 py-12">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-2xl font-semibold mb-8">
            Special Stores
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Education Store */}
            <div className="bg-[#f5f5f7] rounded-xl p-6">
              <h3 className="text-lg font-semibold mb-2">
                Education
              </h3>
              <p className="text-gray-600 mb-3">
                Save on Mac, iPad, and more with education pricing.
              </p>
              <Link
                href="/"
                className="text-blue-500 hover:underline"
              >
                Shop Education Store &gt;
              </Link>
            </div>

            {/* Business Store */}
            <div className="bg-[#f5f5f7] rounded-xl p-6">
              <h3 className="text-lg font-semibold mb-2">
                Business
              </h3>
              <p className="text-gray-600 mb-3">
                From enterprise to small business, we'll work with you.
              </p>
              <Link
                href="/"
                className="text-blue-500 hover:underline"
              >
                Shop Business Store &gt;
              </Link>
            </div>

            {/* Government Store */}
            <div className="bg-[#f5f5f7] rounded-xl p-6">
              <h3 className="text-lg font-semibold mb-2">
                Government
              </h3>
              <p className="text-gray-600 mb-3">
                Special pricing for state, local, and federal agencies.
              </p>
              <Link
                href="/"
                className="text-blue-500 hover:underline"
              >
                Shop Government Store &gt;
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Links */}
      <section className="bg-[#f5f5f7] px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-lg font-semibold mb-4">Quick Links</h2>
          <div className="flex flex-wrap gap-3">
            <Button variant="outline" className="rounded-full bg-white">
              Order Status
            </Button>
            <Button variant="outline" className="rounded-full bg-white">
              Shopping Help
            </Button>
            <Button variant="outline" className="rounded-full bg-white">
              Returns
            </Button>
            <Button variant="outline" className="rounded-full bg-white">
              Your Saves
            </Button>
            <Button variant="outline" className="rounded-full bg-white">
              Find a Store
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
